import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');
  const [companies, setCompanies] = useState([]);
  const [editCompany, setEditCompany] = useState(null);
  const [editShowPassword, setEditShowPassword] = useState(false);
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');
  const navigate = useNavigate();

  useEffect(() => {
    if (role === 'admin' && token) {
      fetchCompanies();
    }
  }, [token, role]);

  const fetchCompanies = async () => {
    try {
      const res = await axios.get('http://localhost:5000/admin/companies', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCompanies(res.data);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Error fetching companies');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        'http://localhost:5000/admin/add-company',
        { fullName, email, password },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMessage(res.data.message);
      setFullName('');
      setEmail('');
      setPassword('');
      setShowPassword(false);
      fetchCompanies();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Error adding company');
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.put(
        `http://localhost:5000/admin/companies/${editCompany.id}`,
        { fullName: editCompany.fullName, email: editCompany.email, password: editCompany.password },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMessage(res.data.message);
      setEditCompany(null);
      setEditShowPassword(false);
      fetchCompanies();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Error updating company');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this company?')) {
      try {
        const res = await axios.delete(`http://localhost:5000/admin/companies/${id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setMessage(res.data.message);
        fetchCompanies();
      } catch (err) {
        setMessage(err.response?.data?.message || 'Error deleting company');
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('fullName');
    navigate('/');
  };

  if (role !== 'admin') return <p>Admin access required.</p>;

  return (
    <div className="admin-dashboard-container">
      <div className="admin-header">
        <h2>Admin Dashboard</h2>
        <button className="logout-btn" onClick={handleLogout}>Logout</button>
      </div>

      <h3>Add New Company</h3>
      <form onSubmit={handleSubmit} className="admin-form">
        <input
          type="text"
          placeholder="Company Name"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="Company Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <div className="password-container">
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <label className="show-password-label">
            <input
              type="checkbox"
              checked={showPassword}
              onChange={() => setShowPassword(!showPassword)}
            />
            Show Password
          </label>
        </div>
        <button type="submit">Add Company</button>
      </form>

      {editCompany && (
        <div>
          <h3>Edit Company</h3>
          <form onSubmit={handleUpdate} className="admin-form">
            <input
              type="text"
              placeholder="Company Name"
              value={editCompany.fullName}
              onChange={(e) => setEditCompany({ ...editCompany, fullName: e.target.value })}
              required
            />
            <input
              type="email"
              placeholder="Company Email"
              value={editCompany.email}
              onChange={(e) => setEditCompany({ ...editCompany, email: e.target.value })}
              required
            />
            <div className="password-container">
              <input
                type={editShowPassword ? 'text' : 'password'}
                placeholder="New Password (optional)"
                value={editCompany.password || ''}
                onChange={(e) => setEditCompany({ ...editCompany, password: e.target.value })}
              />
              <label className="show-password-label">
                <input
                  type="checkbox"
                  checked={editShowPassword}
                  onChange={() => setEditShowPassword(!editShowPassword)}
                />
                Show Password
              </label>
            </div>
            <button type="submit">Update Company</button>
            <button type="button" className="cancel-btn" onClick={() => setEditCompany(null)}>Cancel</button>
          </form>
        </div>
      )}

      <h3>Manage Companies</h3>
      {companies.length === 0 ? (
        <p>No companies added yet.</p>
      ) : (
        <ul className="company-list">
          {companies.map((company) => (
            <li key={company.id} className="company-item">
              <div>
                <strong>Name:</strong> {company.full_name}<br />
                <strong>Email:</strong> {company.email}
              </div>
              <div>
                <button onClick={() => setEditCompany({ ...company, password: '' })}>Edit</button>
                <button className="delete-btn" onClick={() => handleDelete(company.id)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
      <p>{message}</p>
    </div>
  );
};

export default AdminDashboard;