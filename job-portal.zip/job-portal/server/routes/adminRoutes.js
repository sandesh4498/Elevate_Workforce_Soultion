const express = require('express');
const router = express.Router();
const User = require('../models/userModel');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db'); // Add this line

// Middleware to check admin role
const adminMiddleware = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token provided' });
  jwt.verify(token, 'secret_key', (err, decoded) => {
    if (err) return res.status(401).json({ message: 'Invalid token' });
    if (decoded.role !== 'admin') return res.status(403).json({ message: 'Admin access required' });
    req.user = decoded;
    next();
  });
};

// Add a company (admin only)
router.post('/add-company', adminMiddleware, (req, res) => {
  const { fullName, email, password } = req.body;
  if (!fullName || !email || !password) {
    return res.status(400).json({ message: 'All fields are required' });
  }
  User.findByEmail(email, (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (results.length > 0) {
      return res.status(400).json({ message: 'Email already exists' });
    }
    User.create(fullName, email, password, 'company', (err, result) => {
      if (err) return res.status(500).json({ message: 'Failed to add company' });
      res.status(201).json({ message: 'Company added successfully', id: result.insertId });
    });
  });
});

// List all companies (admin only)
router.get('/companies', adminMiddleware, (req, res) => {
  const query = 'SELECT id, full_name, email FROM users WHERE role = "company"';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Database error:', err); // Log the error
      return res.status(500).json({ message: 'Database error' });
    }
    res.json(results);
  });
});

// Update a company (admin only)
router.put('/companies/:id', adminMiddleware, (req, res) => {
  const { fullName, email, password } = req.body;
  const { id } = req.params;
  if (!fullName || !email) {
    return res.status(400).json({ message: 'Full name and email are required' });
  }
  
  User.findByEmail(email, (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (results.length > 0 && results[0].id != id) {
      return res.status(400).json({ message: 'Email already in use by another user' });
    }

    let query = 'UPDATE users SET full_name = ?, email = ?';
    const params = [fullName, email];
    if (password) {
      bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) return res.status(500).json({ message: 'Error hashing password' });
        query += ', password = ?';
        params.push(hashedPassword);
        query += ' WHERE id = ? AND role = "company"';
        params.push(id);
        db.query(query, params, (err, result) => {
          if (err) return res.status(500).json({ message: 'Database error' });
          if (result.affectedRows === 0) return res.status(404).json({ message: 'Company not found' });
          res.json({ message: 'Company updated successfully' });
        });
      });
    } else {
      query += ' WHERE id = ? AND role = "company"';
      params.push(id);
      db.query(query, params, (err, result) => {
        if (err) return res.status(500).json({ message: 'Database error' });
        if (result.affectedRows === 0) return res.status(404).json({ message: 'Company not found' });
        res.json({ message: 'Company updated successfully' });
      });
    }
  });
});

// Delete a company (admin only)
router.delete('/companies/:id', adminMiddleware, (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM users WHERE id = ? AND role = "company"';
  db.query(query, [id], (err, result) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Company not found' });
    res.json({ message: 'Company deleted successfully' });
  });
});

module.exports = router;